'use client'

import { useEffect, useState } from 'react'
import { X } from 'lucide-react'

interface AutoPopupProps {
  onClose?: () => void
}

export default function AutoPopup({ onClose }: AutoPopupProps) {
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsOpen(true)
    }, 5000)

    return () => clearTimeout(timer)
  }, [])

  if (!isOpen) return null

  const handleClose = () => {
    setIsOpen(false)
    onClose?.()
  }

  const handleCall = () => {
    window.location.href = 'tel:+1-800-555-0123'
  }

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 z-40 transition-opacity duration-300"
        onClick={handleClose}
      />

      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md mx-4">
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl shadow-2xl border border-slate-700 overflow-hidden">
          {/* Close Button */}
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 p-2 hover:bg-slate-700 rounded-lg transition-colors duration-200 z-10"
            aria-label="Close"
          >
            <X className="w-5 h-5 text-slate-400 hover:text-white" />
          </button>

          {/* Content */}
          <div className="p-8 pt-12">
            {/* Headline */}
            <h2 className="text-2xl font-bold text-white mb-3 leading-tight">
              Internet or Cable Not Working?
            </h2>

            {/* Subtext */}
            <p className="text-slate-300 text-base mb-6 leading-relaxed">
              Get instant help for slow internet, outages, setup issues, or cable problems.
            </p>

            {/* CTA Button */}
            <button
              onClick={handleCall}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-4 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg mb-4"
            >
              CALL SUPPORT NOW
            </button>

            {/* Trust Line */}
            <p className="text-xs text-slate-400 text-center leading-relaxed">
              Quick assistance • No forms • Talk to a real agent
            </p>

            {/* Compliance Disclaimer */}
            <p className="text-xs text-slate-500 text-center mt-4 pt-4 border-t border-slate-700">
              Independent third-party assistance • Not affiliated with any provider
            </p>
          </div>
        </div>
      </div>
    </>
  )
}
