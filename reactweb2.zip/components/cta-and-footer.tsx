'use client';

export default function CTAAndFooter() {
  return (
    <>
      {/* Main CTA Section */}
      <section className="relative py-20 md:py-32 bg-gradient-to-b from-gray-900 to-black overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-yellow-500 rounded-full filter blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500 rounded-full filter blur-3xl" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 md:px-8">
          {/* CTA Content */}
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 text-balance">
              Ready to Get Your Issues Resolved?
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto leading-relaxed">
              Don't let connectivity issues slow you down. Get expert help today and get back online with confidence.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <button className="px-10 py-4 bg-yellow-500 text-black font-bold text-lg rounded-lg hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105 shadow-xl">
              Get Help Now
            </button>
            <button className="px-10 py-4 border-2 border-white text-white font-semibold text-lg rounded-lg hover:bg-white/10 transition-all duration-300">
              Schedule a Call
            </button>
          </div>

          {/* Trust line */}
          <p className="text-center text-gray-400">
            24/7 Support • No Long Waits • Real Experts • Money-Back Guarantee
          </p>
        </div>
      </section>

      {/* Sticky Call Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 shadow-2xl z-50">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <p className="text-white font-semibold">Need Immediate Help?</p>
            <p className="text-gray-400 text-sm">Our agents are standing by 24/7</p>
          </div>
          <button className="px-6 py-2 bg-yellow-500 text-black font-bold rounded-lg hover:bg-yellow-400 transition-all duration-300 whitespace-nowrap">
            Call Support: 1-800-NET-HELP
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-black border-t border-gray-800 pt-20 pb-32">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          {/* Footer content */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div>
              <h3 className="text-xl font-bold text-white mb-4">NetGuide</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Expert guidance for all your internet and cable needs.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-white font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>
                  <a href="/how-it-works" className="hover:text-yellow-500 transition-colors">
                    How It Works
                  </a>
                </li>
                <li>
                  <a href="/faq" className="hover:text-yellow-500 transition-colors">
                    FAQ
                  </a>
                </li>
                <li>
                  <a href="/contact" className="hover:text-yellow-500 transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="text-white font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>
                  <a href="tel:1-800-NET-HELP" className="hover:text-yellow-500 transition-colors">
                    1-800-NET-HELP
                  </a>
                </li>
                <li>
                  <a href="mailto:support@netguide.com" className="hover:text-yellow-500 transition-colors">
                    support@netguide.com
                  </a>
                </li>
                <li>
                  <span className="text-yellow-500">24/7 Available</span>
                </li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>
                  <a href="/privacy" className="hover:text-yellow-500 transition-colors">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="/terms" className="hover:text-yellow-500 transition-colors">
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a href="/disclaimer" className="hover:text-yellow-500 transition-colors">
                    Disclaimer
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Compliance Disclosure */}
          <div className="border-t border-gray-800 pt-8 mb-8">
            <p className="text-gray-400 text-xs text-center leading-relaxed mb-2">
              <span className="font-semibold text-gray-300">NetGuide</span> is an independent third-party service assistance provider. We are not affiliated with, authorized by, or endorsed by any internet service provider (ISP), cable provider, or telecom company. All provider names mentioned are used strictly for informational purposes only.
            </p>
          </div>

          {/* Bottom bar */}
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500 text-sm text-center md:text-left">
              © 2024 NetGuide. All rights reserved.
            </p>
            <div className="flex gap-6">
              <a
                href="#"
                className="text-gray-400 hover:text-yellow-500 transition-colors"
                aria-label="Twitter"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2s9 5 20 5a9.5 9.5 0 00-9-5.5c4.75 2.25 7-7 7-7" />
                </svg>
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-yellow-500 transition-colors"
                aria-label="Facebook"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18 2h-3a6 6 0 00-6 6v3H7v4h2v8h4v-8h3l1-4h-4V8a1 1 0 011-1h3z" />
                </svg>
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-yellow-500 transition-colors"
                aria-label="LinkedIn"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
