'use client';

import { useEffect, useRef, useState } from 'react';

interface HeroSectionProps {
  onOpenModal?: () => void
}

export default function HeroSection({ onOpenModal }: HeroSectionProps) {
  const [scrollY, setScrollY] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section className="relative h-screen w-full overflow-hidden">
      {/* Sticky background with parallax effect */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url(/hero-background.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
          transform: `translateY(${scrollY * 0.5}px)`,
        }}
      >
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/50" />
      </div>

      {/* Content overlay */}
      <div className="relative z-10 h-full flex items-center justify-center">
        <div className="flex flex-col items-center justify-center text-center px-4 md:px-8 max-w-3xl">
          {/* Main headline */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight text-balance">
            Internet & Cable Issues?
          </h1>

          {/* Subheading with accent */}
          <p className="text-xl md:text-2xl text-gray-200 mb-8 leading-relaxed max-w-2xl">
            We're Here to Guide You
          </p>

          {/* Accent line */}
          <div className="w-16 h-1 bg-gradient-to-r from-transparent via-yellow-500 to-transparent mb-8" />

          {/* Description */}
          <p className="text-lg md:text-xl text-gray-300 mb-10 max-w-xl leading-relaxed">
            Expert guidance for outages, slow WiFi, setup issues & cable problems. Get help from professionals who understand your frustrations.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={onOpenModal}
              className="px-8 py-4 bg-white text-black font-semibold text-lg rounded-lg hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Get Help Now
            </button>
            <a
              href="#features"
              className="px-8 py-4 border-2 border-white text-white font-semibold text-lg rounded-lg hover:bg-white/10 transition-all duration-300"
            >
              Learn More
            </a>
          </div>

          {/* Trust indicators */}
          <div className="mt-12 flex flex-col sm:flex-row gap-8 text-sm text-gray-300">
            <div className="flex items-center gap-2">
              <span className="text-yellow-500 text-xl">✓</span>
              <span>Quick Help</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-yellow-500 text-xl">✓</span>
              <span>Real Agents</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-yellow-500 text-xl">✓</span>
              <span>Expert Guidance</span>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 flex flex-col items-center animate-bounce">
        <span className="text-white text-sm mb-2">Scroll to explore</span>
        <svg
          className="w-6 h-6 text-white"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
      </div>
    </section>
  );
}
