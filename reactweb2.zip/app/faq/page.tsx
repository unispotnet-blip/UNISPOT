'use client'

import { useState } from 'react'
import Header from '@/components/header'
import FloatingCallButton from '@/components/floating-call-button'
import StickyCallBar from '@/components/sticky-call-bar'
import CallModal from '@/components/call-modal'
import CTAAndFooter from '@/components/cta-and-footer'
import { ChevronDown } from 'lucide-react'

const faqCategories = [
  {
    name: "General",
    faqs: [
      {
        question: "How long does it take to get help?",
        answer:
          "Most customers get connected with a technician within 5-10 minutes. For urgent issues, we have priority lines available 24/7.",
      },
      {
        question: "Do you work with all internet providers?",
        answer:
          "Yes! We support all major providers including Comcast, Verizon, AT&T, Charter, Spectrum, Cox, and many others. Our experts are trained across all major ISPs.",
      },
      {
        question: "What if the issue is not resolved?",
        answer:
          "If we cannot resolve your issue, we provide a 100% refund with no questions asked. Your satisfaction is our guarantee.",
      },
      {
        question: "Can I get support outside business hours?",
        answer:
          "Absolutely! We offer 24/7 support. Call anytime, day or night, weekends or holidays, and we will be ready to help.",
      },
    ],
  },
  {
    name: "Services",
    faqs: [
      {
        question: "What types of issues can you help with?",
        answer:
          "We help with internet outages, slow WiFi speeds, cable issues, setup problems, router configuration, modem problems, connectivity issues, and more. Basically anything related to your internet or cable service.",
      },
      {
        question: "Do I need to have technical knowledge?",
        answer:
          "Not at all! Our experts are trained to guide people of all technical levels. We explain everything clearly and walk you through each step.",
      },
      {
        question: "Can you help with billing questions?",
        answer:
          "While our primary focus is technical support, we can often help with basic billing questions or direct you to the right department.",
      },
      {
        question: "Do you offer remote assistance?",
        answer:
          "We guide you through troubleshooting over the phone. If more complex assistance is needed, we can coordinate with your provider for on-site technician visits.",
      },
    ],
  },
  {
    name: "Pricing",
    faqs: [
      {
        question: "What are your pricing plans?",
        answer:
          "We offer single calls for $29, monthly unlimited support for $99, and annual plans for $899. Each plan comes with different levels of support and access.",
      },
      {
        question: "Are there any hidden fees?",
        answer:
          "No hidden fees! Our pricing is transparent and upfront. What you see is what you pay. No surprise charges or additional fees.",
      },
      {
        question: "Can I cancel anytime?",
        answer:
          "Yes! Monthly plans can be cancelled anytime without penalty. No long-term contracts or commitments required.",
      },
      {
        question: "Do you offer discounts?",
        answer:
          "Yes! We offer discounts for annual plans (save 30%), and we frequently run promotions. Subscribe to our newsletter for exclusive offers.",
      },
    ],
  },
  {
    name: "Security & Privacy",
    faqs: [
      {
        question: "Is my personal information secure?",
        answer:
          "Absolutely! We use enterprise-level encryption and security measures. Your data is never shared with third parties and is protected under strict privacy agreements.",
      },
      {
        question: "What information do you need from me?",
        answer:
          "We need your name, phone number, and details about your issue. We do not require access to personal accounts or sensitive financial information.",
      },
      {
        question: "Do you record calls?",
        answer:
          "We may record calls for quality assurance and training purposes. You will be informed at the start of your call if recording is taking place.",
      },
      {
        question: "How do you handle my data?",
        answer:
          "Your data is stored securely and deleted after 90 days unless you request otherwise. We comply with all privacy laws and regulations.",
      },
    ],
  },
  {
    name: "Account",
    faqs: [
      {
        question: "How do I create an account?",
        answer:
          "You can create an account directly through our website or during your first call. It takes less than 2 minutes.",
      },
      {
        question: "Can I upgrade or downgrade my plan?",
        answer:
          "Yes! You can change your plan anytime from your account dashboard. Changes take effect immediately.",
      },
      {
        question: "Do you save my issue history?",
        answer:
          "Yes! We keep detailed records of all issues and resolutions so our team can provide consistent support and prevent recurring problems.",
      },
      {
        question: "How do I access my account?",
        answer:
          "You can access your account through our website with your email and password. You can also call us to manage your account over the phone.",
      },
    ],
  },
]

export default function FAQ() {
  const [modalOpen, setModalOpen] = useState(false)
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>({})
  const [openFAQs, setOpenFAQs] = useState<Record<string, boolean>>({})

  const toggleCategory = (category: string) => {
    setOpenCategories((prev) => ({
      ...prev,
      [category]: !prev[category],
    }))
  }

  const toggleFAQ = (faqKey: string) => {
    setOpenFAQs((prev) => ({
      ...prev,
      [faqKey]: !prev[faqKey],
    }))
  }

  return (
    <>
      <Header />
      <main className="overflow-hidden pt-16">
        {/* Hero */}
        <section className="py-20 px-4 bg-background">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-muted-foreground">
              Find answers to common questions. Can't find what you are looking for?{' '}
              <button
                onClick={() => setModalOpen(true)}
                className="text-accent hover:text-opacity-80 font-semibold"
              >
                Contact us
              </button>
            </p>
          </div>
        </section>

        {/* FAQ Sections */}
        <section className="py-20 px-4 bg-card/50">
          <div className="max-w-4xl mx-auto space-y-8">
            {faqCategories.map((category, categoryIndex) => (
              <div key={categoryIndex} className="border border-border rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleCategory(category.name)}
                  className="w-full px-6 py-4 flex items-center justify-between bg-card hover:bg-secondary transition-colors"
                >
                  <h2 className="text-2xl font-bold text-foreground">
                    {category.name}
                  </h2>
                  <ChevronDown
                    size={24}
                    className={`text-accent transition-transform ${
                      openCategories[category.name] ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {openCategories[category.name] && (
                  <div className="border-t border-border bg-background">
                    <div className="divide-y divide-border">
                      {category.faqs.map((faq, faqIndex) => {
                        const faqKey = `${category.name}-${faqIndex}`
                        return (
                          <div key={faqIndex}>
                            <button
                              onClick={() => toggleFAQ(faqKey)}
                              className="w-full px-6 py-4 flex items-start justify-between hover:bg-card/50 transition-colors text-left"
                            >
                              <span className="font-semibold text-foreground pr-4">
                                {faq.question}
                              </span>
                              <ChevronDown
                                size={20}
                                className={`text-accent flex-shrink-0 mt-1 transition-transform ${
                                  openFAQs[faqKey] ? 'rotate-180' : ''
                                }`}
                              />
                            </button>

                            {openFAQs[faqKey] && (
                              <div className="px-6 py-4 bg-card/50 border-t border-border">
                                <p className="text-muted-foreground leading-relaxed">
                                  {faq.answer}
                                </p>
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Still Have Questions */}
        <section className="py-20 px-4 bg-background">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-foreground mb-6">
              Still Have Questions?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Our support team is ready to help with any questions or concerns you might have.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => setModalOpen(true)}
                className="px-8 py-4 bg-accent text-accent-foreground rounded-lg font-semibold hover:opacity-90 transition-opacity"
              >
                Contact Support
              </button>
              <a
                href="tel:+1-800-000-0000"
                className="px-8 py-4 border-2 border-accent text-accent rounded-lg font-semibold hover:bg-accent/10 transition-colors"
              >
                Call Now
              </a>
            </div>
          </div>
        </section>

        <CTAAndFooter />
      </main>

      <FloatingCallButton onOpen={() => setModalOpen(true)} />
      <StickyCallBar onOpenModal={() => setModalOpen(true)} />
      <CallModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  )
}
